package service;

public class InventoryService {
}
