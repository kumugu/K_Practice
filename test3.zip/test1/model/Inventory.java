package model;

public class Inventory {
}
