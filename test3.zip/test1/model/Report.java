package model;

public class Report {
}
