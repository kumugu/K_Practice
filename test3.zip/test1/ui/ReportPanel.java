package ui;

public class ReportPanel {
}
