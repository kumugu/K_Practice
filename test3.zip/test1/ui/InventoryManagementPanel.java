package ui;

public class InventoryManagementPanel {
}
