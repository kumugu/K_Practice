package ui;

import javax.swing.*;
import java.awt.*;

public class MainFrame extends JFrame {
    private CardLayout cardLayout;
    private JPanel mainPanel;

    public MainFrame() {
        setTitle("관리 시스템");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // 메뉴 바 설정
        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("파일");
        JMenuItem exitMenuItem = new JMenuItem("종료");
        exitMenuItem.addActionListener(e -> System.exit(0));
        fileMenu.add(exitMenuItem);
        menuBar.add(fileMenu);
        setJMenuBar(menuBar);

        // 좌측 버튼 패널
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.Y_AXIS));

        JButton menuButton = new JButton("메뉴 관리");
        JButton inventoryButton = new JButton("재고 관리");
        JButton reportButton = new JButton("보고서");

        buttonPanel.add(menuButton);
        buttonPanel.add(inventoryButton);
        buttonPanel.add(reportButton);

        // 중앙 메인 패널
        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);

        mainPanel.add(new MenuManagementPanel(), "MenuManagement");
//        mainPanel.add(new InventoryManagementPanel(), "InventoryManagement");
//        mainPanel.add(new ReportPanel(), "Report");

        menuButton.addActionListener(e -> cardLayout.show(mainPanel, "MenuManagement"));
        inventoryButton.addActionListener(e -> cardLayout.show(mainPanel, "InventoryManagement"));
        reportButton.addActionListener(e -> cardLayout.show(mainPanel, "Report"));

        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(buttonPanel, BorderLayout.WEST);
        getContentPane().add(mainPanel, BorderLayout.CENTER);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MainFrame frame = new MainFrame();
            frame.setVisible(true);
        });
    }
}
