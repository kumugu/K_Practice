package ui;

import model.Product;
import service.ProductService;
import javax.swing.*;
import java.awt.*;

public class MenuManagementPanel extends JPanel {
    private ProductService productService = new ProductService();

    public MenuManagementPanel() {
        setLayout(new BorderLayout());
        // 상품 관리 UI구성
        JPanel productPanel = new JPanel(new GridLayout(0, 1));
        productPanel.setBorder(BorderFactory.createTitledBorder("상품 관리"));

        JButton addButton = new JButton("상품 추가");
        JButton editButton = new JButton("상품 수정");
        JButton deleteButton = new JButton("상품 삭제");

        productPanel.add(addButton);
        productPanel.add(editButton);
        productPanel.add(deleteButton);

        add(productPanel, BorderLayout.NORTH);

        addButton.addActionListener(e -> addProduct());
        editButton.addActionListener(e -> editProdct());
        deleteButton.addActionListener(e -> deleteProduct());
    }


    private void addProduct() {
        String productName = JOptionPane.showInputDialog("상품 이름을 입력 하세요  : ");
        if (productName != null & !productName.isEmpty()) {
            Product product = new Product();
            product.setName(productName);
            product.setPrice(Double.parseDouble((JOptionPane.showInputDialog("가격을 입력하세요"))));
            productService.addProduct(product);
            JOptionPane.showMessageDialog(this, "상품이 추가되었습니다.");
        }
    }


    private void editProdct() {
        String productIdStr = JOptionPane.showInputDialog("수정할 상품 ID를 입력하세요 : ");
        if (productIdStr != null && !productIdStr.isEmpty()) {
            int productId = Integer.parseInt(productIdStr);
            Product product = productService.getAllProducts().stream()
                    .filter(p -> p.getId() == productId)
                    .findFirst().orElse(null);
            if (product != null) {
                String newProductName = JOptionPane.showInputDialog("새로운 상품 이름을 입력하세요 : ", product.getName());
                String newProductPriceStr = JOptionPane.showInputDialog("새로운 가격을 입력하세요 : ", product.getPrice());
                if (newProductName != null && !newProductName.isEmpty() && newProductPriceStr != null && !newProductPriceStr.isEmpty()) {
                    double newProductPrice = Double.parseDouble(newProductPriceStr);
                    product.setName(newProductName);
                    product.setPrice(newProductPrice);
                    productService.updateProduct(product);
                    JOptionPane.showMessageDialog(this, "상품이 수정되었습니다.");
                }
            } else {
                JOptionPane.showMessageDialog(this, "해당 ID의 상품을 찾을 수 없습니다.");
            }
        }
    }


    private void deleteProduct() {
        String productIdstr = JOptionPane.showInputDialog("삭제할 상품 ID를 입력하세요 : ");
        if (productIdstr != null && !productIdstr.isEmpty()) {
            int productId = Integer.parseInt(productIdstr);
            Product product = productService.getAllProducts().stream()
                    .filter(p -> p.getId() == productId)
                    .findFirst().orElse(null);
            if (product != null) {
                productService.deleteProduct(productId);
                JOptionPane.showMessageDialog(this, "상품이 삭제되었습니다.");
            } else {
                JOptionPane.showMessageDialog(this, "해당 ID의 상품을 찾을 수 없습니다.");
            }
        }
    }


}
