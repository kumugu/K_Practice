package db;

public class InventoryDAO {
}
