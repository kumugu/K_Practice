package ui;

import javax.swing.*;
import java.awt.*;

// 재고 관리 화면 관련 코드
public class InventoryPanel extends JPanel {
    public InventoryPanel() {
        setLayout(new BorderLayout());

        // 재고 조회
        JPanel inventoryViewPanel = new JPanel(new BorderLayout());
        JTable inventoryTable = new JTable(); // 테이블 모델은 별도로 설정
        JScrollPane inventoryScrollPane = new JScrollPane(inventoryTable);

        inventoryViewPanel.add(inventoryScrollPane, BorderLayout.CENTER);

        // 재료 주문
        JPanel orderPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        JLabel materialLabel = new JLabel("재료:");
        JTextField materialField = new JTextField(15);
        JButton orderButton = new JButton("주문");

        gbc.gridx = 0;
        gbc.gridy = 0;
        orderPanel.add(materialLabel, gbc);

        gbc.gridx = 1;
        orderPanel.add(materialField, gbc);

        gbc.gridx = 1;
        gbc.gridy = 1;
        orderPanel.add(orderButton, gbc);

        add(inventoryViewPanel, BorderLayout.NORTH);
        add(orderPanel, BorderLayout.SOUTH);
    }
}

