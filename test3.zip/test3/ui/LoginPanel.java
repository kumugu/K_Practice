package ui;

import javax.swing.*;
import java.awt.*;

public class LoginPanel extends JPanel {
    public LoginPanel() {
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        JLabel idLabel = new JLabel("아이디:");
        JTextField idField = new JTextField(15);

        JLabel passwordLabel = new JLabel("비밀번호:");
        JPasswordField passwordField = new JPasswordField(15);

        JButton loginButton = new JButton("로그인");
        JButton signupButton = new JButton("회원가입");

        gbc.gridx = 0;
        gbc.gridy = 0;
        add(idLabel, gbc);

        gbc.gridx = 1;
        add(idField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        add(passwordLabel, gbc);

        gbc.gridx = 1;
        add(passwordField, gbc);

        gbc.gridx = 1;
        gbc.gridy = 2;
        add(loginButton, gbc);

        gbc.gridy = 3;
        add(signupButton, gbc);

        loginButton.addActionListener(e -> {
            // 로그인 로직
            MainFrame.showLobby(); // 로그인 성공 시 로비 화면으로 이동
        });

        signupButton.addActionListener(e -> {
            // 회원가입 페이지로 이동
            MainFrame.showSignUp();
        });
    }
}

