package ui;

import javax.swing.*;
import java.awt.*;

public class ReportPanel extends JPanel {
    public ReportPanel() {
        setLayout(new BorderLayout());

        // 매출 보고서
        JPanel salesReportPanel = new JPanel(new BorderLayout());
        // 차트 및 표를 표시하는 컴포넌트 추가

        // 재료 소진 보고서
        JPanel materialReportPanel = new JPanel(new BorderLayout());
        // 테이블 컴포넌트 추가

        // 판매 현황
        JPanel salesStatusPanel = new JPanel(new BorderLayout());
        // 그래프 컴포넌트 추가

        add(salesReportPanel, BorderLayout.NORTH);
        add(materialReportPanel, BorderLayout.CENTER);
        add(salesStatusPanel, BorderLayout.SOUTH);
    }
}
