package ui;

import javax.swing.*;
import java.awt.*;

public class SignUpPanel extends JPanel {
    // 회원가입 화면 관련 코드
}
