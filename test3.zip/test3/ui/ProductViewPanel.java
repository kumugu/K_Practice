package ui;

import javax.swing.*;
import java.awt.*;

public class ProductViewPanel extends JPanel {
    public ProductViewPanel() {
        setLayout(new BorderLayout());

        JPanel searchPanel = new JPanel(new FlowLayout());
        JTextField searchField = new JTextField(20);
        JButton searchButton = new JButton("검색");
        JButton viewAllButton = new JButton("전체 조회");

        searchPanel.add(viewAllButton);
        searchPanel.add(searchField);
        searchPanel.add(searchButton);

        JTable productTable = new JTable(); // 테이블 모델은 별도로 설정
        JScrollPane scrollPane = new JScrollPane(productTable);

        add(searchPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
    }
}
