package ui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class MainFrame extends JFrame {
    public static final String MENU_PANEL = "상품 관리";
    public static final String INVENTORY_PANEL = "재고 관리";
    public static final String REPORT_PANEL = "보고서 관리";
    public static final String LOGIN_PANEL = "로그인";
    public static final String LOBBY_PANEL = "로비";
    public static final String SIGNUP_PANEL = "회원가입";

    private static JPanel centerPanel;

    public MainFrame() {
        setTitle("매장 관리 프로그램");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 700);
        setLocationRelativeTo(null);

        // 메뉴 바 추가
        createMenuBar();

        // 메인 콘텐츠 패널
        JPanel contentPane = new JPanel(new BorderLayout());
        setContentPane(contentPane);

        // 중앙 콘텐츠 패널 (CardLayout)
        centerPanel = new JPanel(new CardLayout());
        contentPane.add(centerPanel, BorderLayout.CENTER);

        // 각 화면 초기화
        initPanels();

        setVisible(true);
    }

    private void createMenuBar() {
        JMenuBar menuBar = new JMenuBar();

        JMenu fileMenu = new JMenu("파일");
        JMenuItem printItem = new JMenuItem("인쇄");
        JMenuItem logoutItem = new JMenuItem("로그아웃");
        JMenuItem exitItem = new JMenuItem("종료");
        fileMenu.add(printItem);
        fileMenu.add(logoutItem);
        fileMenu.addSeparator();
        fileMenu.add(exitItem);

        JMenu workMenu = new JMenu("업무");
        JMenuItem menuManageItem = new JMenuItem("메뉴 관리");
        JMenuItem inventoryManageItem = new JMenuItem("재고 관리");
        JMenuItem reportItem = new JMenuItem("보고서");
        workMenu.add(menuManageItem);
        workMenu.add(inventoryManageItem);
        workMenu.add(reportItem);

        JMenu helpMenu = new JMenu("도움말");
        JMenuItem infoItem = new JMenuItem("정보");
        helpMenu.add(infoItem);

        menuBar.add(fileMenu);
        menuBar.add(workMenu);
        menuBar.add(helpMenu);

        setJMenuBar(menuBar);

        // 메뉴 항목에 액션 리스너 추가
        menuManageItem.addActionListener(e -> showPanel(MENU_PANEL));
        inventoryManageItem.addActionListener(e -> showPanel(INVENTORY_PANEL));
        reportItem.addActionListener(e -> showPanel(REPORT_PANEL));
        logoutItem.addActionListener(e -> showPanel(LOGIN_PANEL));
    }

    private void initPanels() {
        centerPanel.add(new LoginPanel(), LOGIN_PANEL);
        centerPanel.add(new LobbyPanel(), LOBBY_PANEL);
        centerPanel.add(new SignUpPanel(), SIGNUP_PANEL);

        // 상품 관리 화면
        JTabbedPane menuTabbedPane = new JTabbedPane();
        menuTabbedPane.addTab("상품 조회", new ProductViewPanel());
        menuTabbedPane.addTab("상품 추가", new ProductAddPanel());

        // 재고 관리 화면
        JTabbedPane inventoryTabbedPane = new JTabbedPane();
        inventoryTabbedPane.addTab("재고 조회", new InventoryPanel());
        inventoryTabbedPane.addTab("재료 주문", new JPanel()); // 빈 패널로 대체

        // 보고서 화면
        JTabbedPane reportTabbedPane = new JTabbedPane();
        reportTabbedPane.addTab("매출 보고서", new JPanel()); // 빈 패널로 대체
        reportTabbedPane.addTab("재료 소진 보고서", new JPanel()); // 빈 패널로 대체
        reportTabbedPane.addTab("판매 현황", new JPanel()); // 빈 패널로 대체

        centerPanel.add(menuTabbedPane, MENU_PANEL);
        centerPanel.add(inventoryTabbedPane, INVENTORY_PANEL);
        centerPanel.add(reportTabbedPane, REPORT_PANEL);
    }

    public static void showPanel(String panelName) {
        CardLayout cl = (CardLayout) centerPanel.getLayout();
        cl.show(centerPanel, panelName);
    }

    public static void showLobby() {
        showPanel(LOBBY_PANEL);
    }

    public static void showSignUp() {
        showPanel(SIGNUP_PANEL);
    }
}
