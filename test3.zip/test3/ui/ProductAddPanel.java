package ui;

import javax.swing.*;
import java.awt.*;

// 상품 추가 화면 관련 코드
public class ProductAddPanel extends JPanel {
    public ProductAddPanel() {
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        JLabel categoryLabel = new JLabel("카테고리:");
        JComboBox<String> categoryComboBox = new JComboBox<>(new String[]{"카테고리1", "카테고리2"});

        JLabel nameLabel = new JLabel("상품명:");
        JTextField nameField = new JTextField(15);

        JLabel priceLabel = new JLabel("가격:");
        JTextField priceField = new JTextField(15);

        JLabel ingredientsLabel = new JLabel("재료:");
        JTextField ingredientsField = new JTextField(15); // 여러 재료를 추가할 수 있도록

        JLabel descriptionLabel = new JLabel("설명:");
        JTextArea descriptionArea = new JTextArea(3, 15);

        JButton addButton = new JButton("추가");

        gbc.gridx = 0;
        gbc.gridy = 0;
        add(categoryLabel, gbc);

        gbc.gridx = 1;
        add(categoryComboBox, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        add(nameLabel, gbc);

        gbc.gridx = 1;
        add(nameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        add(priceLabel, gbc);

        gbc.gridx = 1;
        add(priceField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        add(ingredientsLabel, gbc);

        gbc.gridx = 1;
        add(ingredientsField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        add(descriptionLabel, gbc);

        gbc.gridx = 1;
        add(new JScrollPane(descriptionArea), gbc);

        gbc.gridx = 1;
        gbc.gridy = 5;
        add(addButton, gbc);

        addButton.addActionListener(e -> {
            // 상품 추가 로직
        });
    }
}
