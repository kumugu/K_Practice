package ui;

import javax.swing.*;
import java.awt.*;

import static ui.MainFrame.*;

public class LobbyPanel extends JPanel {
    // 로비 화면 관련 코드
    public LobbyPanel() {
        setLayout(new BorderLayout());

        JPanel centerPanel = new JPanel(new GridLayout(1, 3, 10, 10));
        JButton menuManageButton = new JButton("메뉴 관리 🍔");
        JButton inventoryManageButton = new JButton("재고 관리 📦");
        JButton reportButton = new JButton("보고서 📊");

        centerPanel.add(menuManageButton);
        centerPanel.add(inventoryManageButton);
        centerPanel.add(reportButton);

        add(centerPanel, BorderLayout.CENTER);

        menuManageButton.addActionListener(e -> MainFrame.showPanel(MainFrame.MENU_PANEL));
        inventoryManageButton.addActionListener(e -> MainFrame.showPanel(MainFrame.INVENTORY_PANEL));
        reportButton.addActionListener(e -> MainFrame.showPanel(MainFrame.REPORT_PANEL));
    }
}

