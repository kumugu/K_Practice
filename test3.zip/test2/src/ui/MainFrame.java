package ui;

import ui.menu.ProductAddPanel;
import ui.menu.ProductDeletePanel;
import ui.menu.ProductEditPanel;
import ui.menu.ProductViewPanel;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class MainFrame extends JFrame {

    private static final String MENU_PANEL = "상품 관리";
    private static final String INVENTORY_PANEL = "재고 관리";
    private static final String REPORT_PANEL = "보고서 관리";

    private JPanel centerPanel;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                new MainFrame();
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public MainFrame() {
        setTitle("매장 관리 프로그램");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 700);
        setLocationRelativeTo(null);

        // 메뉴 바 추가
        createMenuBar();

        // 메인 콘텐츠 패널
        JPanel contentPane = new JPanel(new BorderLayout());
        setContentPane(contentPane);

        // 좌측 메뉴 패널
        JPanel leftPanel = createLeftPanel();
        contentPane.add(leftPanel, BorderLayout.WEST);

        // 중앙 콘텐츠 패널 (CardLayout)
        centerPanel = new JPanel(new CardLayout());
        contentPane.add(centerPanel, BorderLayout.CENTER);

        // 각 화면 초기화
        initPanels();

        setVisible(true);
    }

    private void createMenuBar() {
        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("파일");
        JMenuItem exitItem = new JMenuItem("종료");
        exitItem.addActionListener(e -> System.exit(0));
        fileMenu.add(exitItem);

        menuBar.add(fileMenu);
        setJMenuBar(menuBar);
    }

    private JPanel createLeftPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(new Color(64, 64, 64));
        panel.setBorder(new EmptyBorder(10, 10, 10, 10));

        // 버튼 생성 및 설정
        JButton btnMenu = createButton("상품 관리");
        JButton btnInventory = createButton("재고 관리");
        JButton btnReport = createButton("보고서 관리");

        // 버튼 액션 리스너
        btnMenu.addActionListener(e -> showPanel(MENU_PANEL));
        btnInventory.addActionListener(e -> showPanel(INVENTORY_PANEL));
        btnReport.addActionListener(e -> showPanel(REPORT_PANEL));

        // 버튼 추가
        panel.add(btnMenu);
        panel.add(Box.createVerticalStrut(10)); // 간격
        panel.add(btnInventory);
        panel.add(Box.createVerticalStrut(10));
        panel.add(btnReport);

        return panel;
    }

    private JButton createButton(String text) {
        JButton button = new JButton(text);
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        button.setFont(new Font("맑은 고딕", Font.BOLD, 16));
        button.setBackground(new Color(250, 128, 255));
        button.setForeground(Color.BLACK);
        button.setFocusPainted(false);
        return button;
    }

    private void initPanels() {
        // 상품 관리 화면
        JTabbedPane menuTabbedPane = new JTabbedPane();
        menuTabbedPane.addTab("상품 조회", new ProductViewPanel());
        menuTabbedPane.addTab("상품 추가", new ProductAddPanel());
        menuTabbedPane.addTab("상품 수정", new ProductEditPanel());
        menuTabbedPane.addTab("상품 삭제", new ProductDeletePanel());


        // 재고 관리 화면
        JTabbedPane inventoryTabbedPane = createTabbedPane(
                new String[]{"재고 조회", "재고 수정", "재료 주문"}
        );

        // 보고서 화면
        JTabbedPane reportTabbedPane = createTabbedPane(
                new String[]{"매출 보고서", "기타 보고서"}
        );

        // 중앙 패널에 추가
        centerPanel.add(menuTabbedPane, MENU_PANEL);
        centerPanel.add(inventoryTabbedPane, INVENTORY_PANEL);
        centerPanel.add(reportTabbedPane, REPORT_PANEL);
    }

    private JTabbedPane createTabbedPane(String[] tabTitles) {
        JTabbedPane tabbedPane = new JTabbedPane();

        for (String title : tabTitles) {
            JPanel panel = new JPanel();
            panel.setLayout(new BorderLayout());
            JLabel label = new JLabel(title + " 화면", SwingConstants.CENTER);
            panel.add(label, BorderLayout.CENTER);
            tabbedPane.addTab(title, panel);
        }

        return tabbedPane;
    }

    private void showPanel(String panelName) {
        CardLayout cl = (CardLayout) centerPanel.getLayout();
        cl.show(centerPanel, panelName);
    }
}
