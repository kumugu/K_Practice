package ui.menu;

import javax.swing.*;
import java.awt.*;

public class ProductSearchPanel extends JPanel {
    public ProductSearchPanel() {
        setLayout(new BorderLayout());

        // 검색 영역
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel lblSearch = new JLabel("검색:");
        JTextField txtSearch = new JTextField(20);
        JButton btnSearch = new JButton("검색");
        searchPanel.add(lblSearch);
        searchPanel.add(txtSearch);
        searchPanel.add(btnSearch);

        // 테이블 영역
        String[] columns = {"ID", "이름", "가격", "재고"};
        Object[][] data = {}; // DB 연결 후 데이터 삽입 예정
        JTable table = new JTable(data, columns);
        JScrollPane scrollPane = new JScrollPane(table);

        add(searchPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
    }
}
