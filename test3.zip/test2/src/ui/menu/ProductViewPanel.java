package ui.menu;

import javax.swing.*;
import java.awt.*;

public class ProductViewPanel extends JPanel {

    public ProductViewPanel() {
        setLayout(new BorderLayout());


        String[] columnNames = {"상품명", "가격", "재고"};
        Object[][] data = {
                {"햄버거", 5000, 100},
                {"프라이", 2000, 50},
                {"음료", 1500, 200}
        };


        // JTable을 사용하여 상품 목록을 표시
        JTable table = new JTable(data, columnNames);
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);
    }
}
