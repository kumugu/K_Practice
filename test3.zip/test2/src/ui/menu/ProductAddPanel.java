package ui.menu;

import javax.swing.*;
import java.awt.*;

public class ProductAddPanel extends JPanel {

    public ProductAddPanel() {
        setLayout(new GridLayout(4, 2));

        // 상품명 입력 필드
        JLabel lblName = new JLabel("상품명:");
        JTextField tfName = new JTextField();

        // 가격 입력 필드
        JLabel lblPrice = new JLabel("가격:");
        JTextField tfPrice = new JTextField();

        // 재고 입력 필드
        JLabel lblStock = new JLabel("재고:");
        JTextField tfStock = new JTextField();

        // 추가 버튼
        JButton btnAdd = new JButton("상품 추가");
        btnAdd.addActionListener(e -> {
            // 상품 추가 로직 (DB에 추가 등)
            String name = tfName.getText();
            String price = tfPrice.getText();
            String stock = tfStock.getText();
            JOptionPane.showMessageDialog(this, "상품이 추가되었습니다.\n상품명: " + name + "\n가격: " + price + "\n재고: " + stock);
        });

        // 컴포넌트 배치
        add(lblName);
        add(tfName);
        add(lblPrice);
        add(tfPrice);
        add(lblStock);
        add(tfStock);
        add(new JLabel());  // 빈 라벨 (그리드 레이아웃 조정용)
        add(btnAdd);
    }
}
