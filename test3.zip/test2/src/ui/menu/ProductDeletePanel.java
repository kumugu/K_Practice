package ui.menu;

import javax.swing.*;
import java.awt.*;

public class ProductDeletePanel extends JPanel {

    public ProductDeletePanel() {
        setLayout(new GridLayout(2, 2));

        // 상품명 선택 콤보박스
        JLabel lblName = new JLabel("상품명:");
        JComboBox<String> cbName = new JComboBox<>(new String[]{"햄버거", "프라이", "음료"});

        // 삭제 버튼
        JButton btnDelete = new JButton("상품 삭제");
        btnDelete.addActionListener(e -> {
            // 삭제된 상품 정보 처리 로직
            String name = (String) cbName.getSelectedItem();
            JOptionPane.showMessageDialog(this, "상품이 삭제되었습니다.\n상품명: " + name);
        });

        // 컴포넌트 배치
        add(lblName);
        add(cbName);
        add(new JLabel());  // 빈 라벨
        add(btnDelete);
    }
}
