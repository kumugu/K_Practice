package ui.menu;

import javax.swing.*;
import java.awt.*;

public class ProductEditPanel extends JPanel {

    public ProductEditPanel() {
        setLayout(new GridLayout(4, 2));

        // 상품명 선택 콤보박스
        JLabel lblName = new JLabel("상품명:");
        JComboBox<String> cbName = new JComboBox<>(new String[]{"햄버거", "프라이", "음료"});

        // 가격 입력 필드
        JLabel lblPrice = new JLabel("새 가격:");
        JTextField tfPrice = new JTextField();

        // 재고 입력 필드
        JLabel lblStock = new JLabel("새 재고:");
        JTextField tfStock = new JTextField();

        // 수정 버튼
        JButton btnEdit = new JButton("상품 수정");
        btnEdit.addActionListener(e -> {
            // 수정된 상품 정보 처리 로직
            String name = (String) cbName.getSelectedItem();
            String price = tfPrice.getText();
            String stock = tfStock.getText();
            JOptionPane.showMessageDialog(this, "상품이 수정되었습니다.\n상품명: " + name + "\n새 가격: " + price + "\n새 재고: " + stock);
        });

        // 컴포넌트 배치
        add(lblName);
        add(cbName);
        add(lblPrice);
        add(tfPrice);
        add(lblStock);
        add(tfStock);
        add(new JLabel());  // 빈 라벨
        add(btnEdit);
    }
}
