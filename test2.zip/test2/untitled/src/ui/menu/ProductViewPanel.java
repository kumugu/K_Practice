package ui.menu;

import model.Product;
import service.ProductService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

public class ProductViewPanel extends JPanel {
    private final ProductService productService = new ProductService();
    private final JTable productTable;
    private final DefaultTableModel tableModel;
    private final JTextField searchField;

    public ProductViewPanel() {
        setLayout(new BorderLayout());

        // 상단 검색 패널
        JPanel searchPanel = new JPanel(new FlowLayout());
        searchField = new JTextField(20);
        JButton searchButton = new JButton("검색");
        JButton viewAllButton = new JButton("전체 조회");

        searchButton.addActionListener(e -> searchProducts());
        viewAllButton.addActionListener(e -> loadAllProducts());

        searchPanel.add(viewAllButton);
        searchPanel.add(searchField);
        searchPanel.add(searchButton);

        add(searchPanel, BorderLayout.NORTH);

        // 상품 목록 테이블
        String[] columnNames = {"상품번호", "카테고리", "상품명", "가격"};
        tableModel = new DefaultTableModel(columnNames, 0);
        productTable = new JTable(tableModel) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // 모든 셀을 편집 불가능하도록 설정
            }
        };
        productTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        productTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2 && productTable.getSelectedRow() != -1) {
                    int selectedRow = productTable.getSelectedRow();
                    int productId = (int) productTable.getValueAt(selectedRow, 0);
                    showProductOptionsDialog(productId);
                }
            }
        });

        JScrollPane scrollPane = new JScrollPane(productTable);
        add(scrollPane, BorderLayout.CENTER);

        // 초기 전체 상품 로드
        loadAllProducts();
    }

    private void searchProducts() {
        String query = searchField.getText();
        List<Product> products = productService.searchProducts(query);
        loadProductData(products);
    }

    private void loadAllProducts() {
        List<Product> products = productService.getAllProducts();
        loadProductData(products);
    }


    private void loadProductData(List<Product> products) {
        tableModel.setRowCount(0); // 기존 데이터 초기화
        for (Product product : products) {
            Object[] rowData = {
                    product.getId(),
                    product.getCategory(),
                    product.getName(),
                    product.getPrice()
            };
            tableModel.addRow(rowData);
        }
    }

    private void showProductOptionsDialog(int productId) {
        int option = JOptionPane.showOptionDialog(
                this,
                "수정 또는 삭제를 선택하세요.",
                "상품 옵션",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                new String[]{"수정", "삭제"},
                "수정"
        );

        if (option == JOptionPane.YES_OPTION) {
            showProductEditDialog(productId);
        } else if (option == JOptionPane.NO_OPTION) {
            productService.deleteProduct(productId);
            loadAllProducts();
        }
    }

    private void showProductEditDialog(int productId) {
        Product product = productService.getProductById(productId);

        JPanel editPanel = new JPanel(new GridLayout(0, 2, 5, 5));
        JTextField nameField = new JTextField(product.getName());
        JTextField priceField = new JTextField(String.valueOf(product.getPrice()));
        JTextField categoryField = new JTextField(product.getCategory());

        editPanel.add(new JLabel("상품명:"));
        editPanel.add(nameField);
        editPanel.add(new JLabel("가격:"));
        editPanel.add(priceField);
        editPanel.add(new JLabel("카테고리:"));
        editPanel.add(categoryField);

        int result = JOptionPane.showConfirmDialog(this, editPanel, "상품 수정", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            product.setName(nameField.getText());
            product.setPrice(Double.parseDouble(priceField.getText()));
            product.setCategory(categoryField.getText());

            productService.updateProduct(product);
            loadAllProducts();
        }
    }
}
