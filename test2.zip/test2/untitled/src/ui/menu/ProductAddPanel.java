package ui.menu;

import model.Product;
import service.ProductService;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class ProductAddPanel extends JPanel {
    private final ProductService productService = new ProductService();
    private final JTextField nameField = new JTextField(15);
    private final JTextField priceField = new JTextField(10);
    private final JComboBox<String> categoryComboBox = new JComboBox<>(new String[]{"버거류", "사이드", "음료", "기타"});
    private final JPanel ingredientsContainer = new JPanel();
    private final List<JPanel> ingredientPanels = new ArrayList<>();

    public ProductAddPanel() {
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        JLabel categoryLabel = new JLabel("카테고리:");
        JLabel nameLabel = new JLabel("상품명:");
        JLabel priceLabel = new JLabel("가격:");
        JLabel ingredientsLabel = new JLabel("재료:");

        JButton addIngredientButton = new JButton("재료 추가");
        JButton addProductButton = new JButton("추가");

        gbc.gridx = 0;
        gbc.gridy = 0;
        add(categoryLabel, gbc);
        gbc.gridx = 1;
        add(categoryComboBox, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        add(nameLabel, gbc);
        gbc.gridx = 1;
        add(nameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        add(priceLabel, gbc);
        gbc.gridx = 1;
        add(priceField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        add(ingredientsLabel, gbc);
        gbc.gridx = 1;
        add(addIngredientButton, gbc);

        ingredientsContainer.setLayout(new BoxLayout(ingredientsContainer, BoxLayout.Y_AXIS));
        JScrollPane scrollPane = new JScrollPane(ingredientsContainer);
        scrollPane.setPreferredSize(new Dimension(250, 150));

        gbc.gridx = 1;
        gbc.gridy = 4;
        add(scrollPane, gbc);

        gbc.gridx = 1;
        gbc.gridy = 5;
        add(addProductButton, gbc);

        // 재료 추가 버튼 동작
        addIngredientButton.addActionListener(e -> addIngredientPanel());

        // 상품 추가 버튼 동작
        addProductButton.addActionListener(e -> addProduct());
    }

    private void addIngredientPanel() {
        JPanel ingredientPanel = new JPanel(new FlowLayout());
        JComboBox<String> ingredientComboBox = new JComboBox<>(new String[]{"빵", "고기", "양상추", "토마토", "치즈", "소스1"});
        JTextField quantityField = new JTextField(5);
        JButton removeButton = new JButton("제거");

        ingredientPanel.add(ingredientComboBox);
        ingredientPanel.add(quantityField);
        ingredientPanel.add(removeButton);

        removeButton.addActionListener(e -> {
            ingredientsContainer.remove(ingredientPanel);
            ingredientPanels.remove(ingredientPanel);
            ingredientsContainer.revalidate();
            ingredientsContainer.repaint();
        });

        ingredientsContainer.add(ingredientPanel);
        ingredientPanels.add(ingredientPanel);
        ingredientsContainer.revalidate();
        ingredientsContainer.repaint();
    }

    private void addProduct() {
        String name = nameField.getText();
        String category = (String) categoryComboBox.getSelectedItem();
        String priceText = priceField.getText();
        List<String> ingredients = new ArrayList<>();

        for (JPanel panel : ingredientPanels) {
            JComboBox<String> ingredientComboBox = (JComboBox<String>) panel.getComponent(0);
            ingredients.add((String) ingredientComboBox.getSelectedItem());
        }

        // 유효성 검사
        if (name.isEmpty() || priceText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "상품명과 가격은 필수 입력 항목입니다.");
            return;
        }

        try {
            name = nameField.getText();
            category = (String) categoryComboBox.getSelectedItem();
            double price = Double.parseDouble(priceField.getText()); // 숫자 검증

            // 상품 객체 생성
            Product product = new Product();
            product.setName(name);
            product.setCategory(category);
            product.setPrice(price);

            // 상품 추가
            productService.addProduct(product);
            JOptionPane.showMessageDialog(this, "상품이 추가되었습니다!");
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "가격에 유효한 숫자를 입력하세요!", "입력 오류", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void addIngredientPanel(JPanel container) {
        JPanel ingredientPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JComboBox<String> ingredientComboBox = new JComboBox<>(new String[]{"빵", "고기", "양상추", "치즈", "소스"});
        JTextField quantityField = new JTextField(5);
        JButton removeButton = new JButton("제거");

        ingredientPanel.add(ingredientComboBox);
        ingredientPanel.add(quantityField);
        ingredientPanel.add(removeButton);

        removeButton.addActionListener(e -> {
            container.remove(ingredientPanel);
            container.revalidate();
            container.repaint();
        });

        container.add(ingredientPanel);
        container.revalidate();
        container.repaint();
    }

}
