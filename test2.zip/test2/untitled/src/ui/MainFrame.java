package ui;

import ui.menu.ProductAddPanel;
import ui.menu.ProductViewPanel;

import javax.swing.*;
import java.awt.*;

public class MainFrame extends JFrame {
    private JPanel centerPanel;

    public MainFrame() {
        setTitle("매장 관리 프로그램");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 700);
        setLocationRelativeTo(null);

        // 메뉴바 설정
        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("파일");
        JMenuItem exitItem = new JMenuItem("종료");
        fileMenu.add(exitItem);
        menuBar.add(fileMenu);
        setJMenuBar(menuBar);

        // 센터 패널
        centerPanel = new JPanel(new CardLayout());
        setContentPane(centerPanel);

        initPanels();

        setVisible(true);
    }


    private void initPanels() {
        JTabbedPane menuTabbedPane = new JTabbedPane();
        menuTabbedPane.addTab("상품 조회", new ProductViewPanel());
        menuTabbedPane.addTab("상품 추가", new ProductAddPanel());

        centerPanel.add(menuTabbedPane, "메뉴 관리");

        // 초기 화면 설정
        showPanel("메뉴 관리");
    }


    public void showPanel(String panelName) {
        CardLayout cl = (CardLayout) centerPanel.getLayout();
        cl.show(centerPanel, panelName);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(MainFrame::new);
    }
}
