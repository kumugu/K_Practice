package service;

import db.DBConnection;
import model.Ingredient;
import model.Product;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProductService {

    // 상품 추가
    public void addProduct(Product product) {
        String productQuery = "INSERT INTO PRODUCTS (ID, NAME, CATEGORY, PRICE) VALUES (PRODUCT_SEQ.NEXTVAL, ?, ?, ?)";
        String ingredientQuery = "INSERT INTO PRODUCT_INGREDIENTS (PRODUCT_ID, INGREDIENT_ID, QUANTITY) VALUES (?, ?, ?)";

        try (Connection conn = DBConnection.getInstance().getConnection()) {
            // 상품 추가
            try (PreparedStatement pstmt = conn.prepareStatement(productQuery, Statement.RETURN_GENERATED_KEYS)) {
                pstmt.setString(1, product.getName());
                pstmt.setString(2, product.getCategory());
                pstmt.setDouble(3, product.getPrice());
                pstmt.executeUpdate();

                ResultSet rs = pstmt.getGeneratedKeys();
                if (rs.next()) {
                    product.setId(rs.getInt(1));
                }
            }

            // 재료 추가
            try (PreparedStatement pstmt = conn.prepareStatement(ingredientQuery)) {
                for (Ingredient ingredient : product.getIngredients()) {
                    pstmt.setInt(1, product.getId());
                    pstmt.setInt(2, ingredient.getId());
                    pstmt.setDouble(3, ingredient.getQuantity());
                    pstmt.addBatch();
                }
                pstmt.executeBatch();
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // 전체 상품 조회
    public List<Product> getAllProducts() {
        List<Product> products = new ArrayList<>();
        String productQuery = "SELECT * FROM PRODUCTS";
        String ingredientQuery = "SELECT i.ID, i.NAME, pi.QUANTITY " +
                "FROM INGREDIENTS i " +
                "JOIN PRODUCT_INGREDIENTS pi ON i.ID = pi.INGREDIENT_ID " +
                "WHERE pi.PRODUCT_ID = ?";

        try (Connection conn = DBConnection.getInstance().getConnection();
             PreparedStatement productStmt = conn.prepareStatement(productQuery)) {

            ResultSet rs = productStmt.executeQuery();
            while (rs.next()) {
                Product product = new Product();
                product.setId(rs.getInt("ID"));
                product.setName(rs.getString("NAME"));
                product.setCategory(rs.getString("CATEGORY"));
                product.setPrice(rs.getDouble("PRICE"));

                // 재료 조회
                try (PreparedStatement ingredientStmt = conn.prepareStatement(ingredientQuery)) {
                    ingredientStmt.setInt(1, product.getId());
                    ResultSet ingredientRs = ingredientStmt.executeQuery();

                    List<Ingredient> ingredients = new ArrayList<>();
                    while (ingredientRs.next()) {
                        Ingredient ingredient = new Ingredient(
                                ingredientRs.getInt("ID"),
                                ingredientRs.getString("NAME"),
                                ingredientRs.getDouble("QUANTITY")
                        );
                        ingredients.add(ingredient);
                    }
                    product.setIngredients(ingredients);
                }
                products.add(product);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return products;
    }

    public List<Product> searchProducts(String query) {
        return List.of();
    }

    public void deleteProduct(int productId) {
    }

    public Product getProductById(int productId) {
        return null;
    }

    public void updateProduct(Product product) {
    }
}
